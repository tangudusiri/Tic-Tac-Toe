import './App.css';
import TicToe from './components/tic';

function App() {
  return (
    <div className="App">
      <TicToe/>
    </div>
  );
}

export default App;
